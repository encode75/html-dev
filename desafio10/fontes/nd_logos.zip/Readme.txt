- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

-  If you need a custom license please contact us at
aimcreative1@gmail.com

- Any donation are very appreciated. Paypal account for donation
https://paypal.me/AimCreative


Thank you.

-------------------
